<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form by Colorlib</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- Register -->
    <?php
    include "_partials/_nav.php";
    ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header">
        <h1 class="display-3 text-uppercase text-white mb-3">Register</h1>
        <div class="d-inline-flex text-white">
            <h6 class="text-uppercase m-0"><a class="text-white" href="">Home</a></h6>
            <h6 class="text-body m-0 px-3">/</h6>
            <h6 class="text-uppercase text-body m-0">Register</h6>
        </div>
    </div>
    <!-- Page Header End -->
    <div class="main">
        <div class="container">
            <div class="signup-content" style="display: flex; justify-content: center;align-items: center;">
                <div class="signup-img" style="width:40%">
                    <img src="images/signup.png" width="100%" alt="">
                </div>

                <div class="signup-form" style="width:60%">
                    <form method="POST" class="register-form" id="register-form">
                        <h2>Registration form - Motoheadz</h2>

                        <div class="form-group">
                            <label for="fname">First-Name :</label>
                            <input type="text" name="fname" id="fname" required />
                        </div>
                        <div class="form-group">
                            <label for="mname">Middle-Name :</label>
                            <input type="text" name="mname" id="mname" />
                        </div>
                        <div class="form-group">
                            <label for="mname">Last-Name :</label>
                            <input type="text" name="lname" id="lname" />
                        </div>
                        <div class="form-group">
                            <label for="email">Email-Id :</label>
                            <input type="email" name="email" id="email" required />
                        </div>
                        <div class="form-group">
                            <label for="mobile">Phone-no :</label>
                            <input type="tel" name="mobile" id="mobile">
                        </div>
                        <div class="form-group">
                            <label for="profile">Profile-Photo:</label>
                            <input type="file" name="profile" id="profile">
                        </div>
                        <div class="form-group">
                            <label for="uname">Username:</label>
                            <input type="text" name="uname" id="uname">
                        </div>
                        <div class="form-group">
                            <label for="pass">Password:</label>
                            <input type="password" name="pass" id="pass">
                        </div>
                        <div class="form-group">
                            <label for="cpass">Confirm-Password:</label>
                            <input type="password" name="cpass" id="cpass">
                        </div>

                        <div class="form-submit">
                            <input type="submit" value="Reset All" class="submit" name="reset" id="reset" />
                            <input type="submit" value="Submit Form" class="submit" name="submit" id="submit" />
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>


    <?php
    include "__partials/_footer.php";
    include "__partials/_js.php";
    ?>

    <!-- Register End -->
    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>