(function($) {

  $('#reset').on('click', function(){
      $('#register-form').reset();
  });

})(jQuery);